#pragma once
#include "Board.h"
class Player
{
public:
	Board board;
	Player() {
		board.SetGlobCord(5, 0);
	}
	
};

