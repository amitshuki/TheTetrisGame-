#pragma once
#include <iostream>
#include <conio.h>


using namespace std;

void gotoxy(size_t x, size_t y);
void clrscr();
bool clearKeyboardBuffer();
